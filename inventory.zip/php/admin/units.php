<?php

    $a = "yeah";